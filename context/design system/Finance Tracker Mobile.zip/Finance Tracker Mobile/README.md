# Finance Tracker Mobile

A calm, minimal mobile UI for the Finance Tracker Flutter app: see this month's spending at a glance, add an expense in a few taps, and keep borrowed and lent money separate.

Built from the existing app in `Finance_Tracker/mobile` (Flutter, `lib/ui/*.dart`) — same data, same backend, same sage brand colour and Roboto (`TrackerSans`) — with the layout simplified. Icons are **Lucide** and charts follow **shadcn/ui charts**, matching the web frontend's `lucide-react` + `recharts` stack.

## What changed, and why

| Before | After | Why |
| --- | --- | --- |
| 4 tabs: Dashboard · Add Expense · All Expenses · Borrow & Lend | 3 tabs: **Home · Activity · Loans** + a floating **+** button | Adding is an action, not a place. A sheet opens over any screen and returns you where you were. |
| Dashboard: 4 stat tiles, loan summary, chart, recent, 2 category panels | **One hero number** (spent this month), one chart, 3 recent rows | One thumb-scroll; the important number is the largest thing on screen. |
| Period button + refresh button + "YOUR SPENDING, IN FOCUS" | Header month pill **‹ Nov 2026 ›** and a privacy eye; pull to refresh | Fewer controls, same functions. Background refresh every 15 s stays. |
| Category panels on the dashboard | A shadcn **donut** + category chips in **Activity** | Breakdown lives next to the list it filters. |
| Full-page expense form with dropdowns | **Bottom sheet**: amount → category grid → date chips → note → Save | Amount first, big; categories are one tap instead of a dropdown. |
| Delete confirm dialogs | Swipe to delete / settle, with **Undo** snackbar | Faster, still forgiving. |
| Red error container | Amber **banner** with Retry, sync dot on the hero | Offline is a state, not an error; saved data stays visible. |
| Loan list sorted with strike-through | **Open · Settled** segmented control, two balance tiles | Outstanding money first. |

## Screens

See the **Screens** group: Home, Activity, Add expense (sheet), Loans. Every screen uses a 16px side gutter, 16px between blocks, a 48px header and the 80px bottom nav. Edit opens the same sheet as Add, prefilled, with Delete.

## Principles

1. **One primary number per screen.** Hero amounts use `amount-hero`; everything else is `body` or smaller.
2. **Colour means something.** Neutral UI; `brand` (sage) for the primary action, today and money owed to you; `owe` (amber) for money you owe; `cat-*` only for category icons and bars; `danger` only for delete and errors.
3. **Hairlines, not shadows.** Cards are `surface` with a `line` border and `radius-lg`. Only the FAB and the sheet cast a shadow.
4. **Thumb first.** Primary actions sit in the bottom third: FAB, sheet Save button, swipe actions. Touch targets ≥ 40px.
5. **Forgive, don't ask.** Undo instead of confirm; never block on the network.

## Voice

Short, plain, sentence case. Name the thing: "Expense added", "Can't reach the server. Showing saved data." No exclamation marks, no emoji. Amounts are Indian rupees with Indian grouping (`₹1,24,560.00`); compact form `₹3.12L` only in secondary stats. Privacy mode replaces every amount with `••••••` and never shifts layout.

## Colour

Two themes, light first. Every text token's note states its contrast; all text pairs are ≥ 4.5:1 in both themes, category colours ≥ 3:1 as icons on `surface`/`surface-2`.

- Ground: `bg` → `surface` → `surface-2` (inputs, wells, segmented track).
- Text: `ink`, `ink-muted`; `ink-faint` is for non-text only.
- Brand: `brand` fill with `on-brand` text; `brand-soft` tint with `brand-ink` text.
- Money direction: `brand` = owed to you, `owe` = you owe — always with a word ("Lent", "Borrowed") so colour is never the only cue.

## Type

Roboto as `TrackerSans` (Regular 400, Bold 700 — the files already bundled in the app). Eight styles: `amount-hero`, `amount-md`, `title`, `heading`, `body`, `label`, `caption`, `overline`. Tabular numbers are not required; keep amounts right-aligned in rows.

## Iconography

**Lucide** — the icon set shadcn/ui ships with (the web frontend already uses `lucide-react`). 24px grid, 2px stroke, round caps and joins, never filled. The previews embed the exact geometry from `lucide-react` 1.31.0 (ISC licence).

| Use | Lucide name |
| --- | --- |
| Nav | `house`, `list`, `users` |
| Actions | `plus`, `search`, `calendar`, `x`, `trash-2`, `check`, `refresh-cw`, `text-align-start` |
| Header | `chevron-left`, `chevron-right`, `eye`, `eye-off` |
| Loans | `arrow-up-right` (owed to you), `arrow-down-left` (you owe) |
| Status | `wifi-off` |
| Gym · Food & Dining · Shopping · Bills & Utilities | `dumbbell` · `utensils` · `shopping-bag` · `receipt` |
| Transportation · Entertainment · Health & Fitness · Travel | `car` · `clapperboard` · `heart-pulse` · `plane` |
| Investment · Education · Others | `trending-up` · `graduation-cap` · `layout-grid` |

Category icons sit in a 40px `surface-2` well, stroked in their `cat-*` colour; UI icons take the text colour around them. In Flutter use the `lucide_icons_flutter` package (same names, camelCase: `LucideIcons.utensils`) in place of Material `Icons.*`.

## Charts

Charts follow **shadcn/ui charts** (Recharts inside `ChartContainer`, tokens as `--chart-*`):

- **SpendingChart**: shadcn *Bar Chart* — horizontal grid only, no axis lines, `radius={4}` bars, today in `chart-1`, other days `chart-muted`, `ChartTooltipContent` card.
- **CategoryDonut**: shadcn *Pie Chart – Donut with Text* — `cat-*` slices with a 5px `surface` gap, total in the centre, square-indicator legend with percentages.
- `chart-1` aliases `brand`, `chart-muted` aliases `ink-faint`, `chart-grid` aliases `line`, tooltip uses `shadow-tip`. Never a gradient, never 3D, no more than one highlighted series.
- Flutter has no Recharts; reproduce the same look with `fl_chart` (settings in each component's notes).

## Implementing in Flutter

The previews use `components/bundle.css` (class prefix `ft-`) so they render here; the app itself should map tokens into `lib/ui/theme.dart`:

```dart
// light
const bg = Color(0xFFF5F7F5), surface = Colors.white, surface2 = Color(0xFFEEF1EE);
const line = Color(0xFFE3E7E3), ink = Color(0xFF17201B), inkMuted = Color(0xFF5C6A62);
const brand = Color(0xFF3F7A64), brandSoft = Color(0xFFE4EFE9), brandInk = Color(0xFF30604D);
const owe = Color(0xFF9A4F1C), oweSoft = Color(0xFFF8EBE1), danger = Color(0xFFB3261E);
// dark: bg 0xFF111412, surface 0xFF181C1A, surface2 0xFF222724, ink 0xFFE9EEEA,
//       inkMuted 0xFF9AA7A0, brand 0xFF7CC2A6, brandSoft 0xFF1D3128, owe 0xFFF0A776
```

- `NavigationBar` with 3 destinations; `indicatorColor: brandSoft`.
- `FloatingActionButton` (56px, `CircleBorder`, `brand`, `LucideIcons.plus`) on Home, Activity and Loans.
- Charts: `fl_chart` styled per SpendingChart and CategoryDonut.
- Add/Edit: `showModalBottomSheet(isScrollControlled: true, showDragHandle: true)` with the existing `ExpenseForm` logic, restyled.
- Swipe actions: `Dismissible` with an Undo `SnackBar`.
- Month pill: two `IconButton`s around a `TextButton` that opens the existing period sheet.
- Replace `ThemeData.colorScheme.fromSeed` with an explicit `ColorScheme` from these tokens, plus a dark `ThemeData` and `themeMode: ThemeMode.system`.

## Spacing & radius

4 · 8 · 12 · 16 · 24 · 32 (`space-1`…`space-6`). Radii: `radius-sm` 8 (bars), `radius-md` 12 (inputs, buttons, wells), `radius-lg` 20 (cards), `radius-xl` 28 (sheet), `radius-pill` (chips, FAB, segmented).
