# Button

Three variants, all 52px tall with `radius-md`.

- **Primary**: `brand` / `on-brand`. One per screen or sheet.
- **Quiet**: `surface-2` / `ink`, for Cancel and secondary actions.
- **Danger**: text-only in `danger`, for Delete.
- Busy state: disabled at 50% with a verb-ing label ("Saving…").
