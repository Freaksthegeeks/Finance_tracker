# FilterControls

Search field, segmented control and chips — the only filter vocabulary in the app.

- Search: 44px, `surface-2`, no border, search icon in `ink-muted`.
- Segmented: `surface-2` track, selected segment `surface` with `ink` label. Used for Month · Year · All, Open · Settled, Lent · Borrowed.
- Chip: 36px pill, `surface` with `line` border; selected chip `brand-soft` / `brand-ink`, no border. Single-select for category.
