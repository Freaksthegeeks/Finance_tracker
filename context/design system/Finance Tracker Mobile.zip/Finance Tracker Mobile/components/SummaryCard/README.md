# SummaryCard

The one hero number: what was spent in the selected month.

- `brand-soft` ground, no border; overline in `brand-ink`, amount in `amount-hero`/`ink`.
- Sub-row: daily average, active categories, all-time total (compact lakh format, e.g. ₹3.12L).
- Sync line: sage dot when fresh; amber dot plus "Showing saved data · time" when stale or offline.
- Privacy on: amounts become dots, layout does not shift.
