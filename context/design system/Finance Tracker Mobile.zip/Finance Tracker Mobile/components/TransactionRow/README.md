# TransactionRow

One expense: category icon, description, meta, amount.

- 40px `surface-2` well with the category icon in its `cat-*` colour; description in `body` (one line, ellipsis); meta in `caption`/`ink-muted`; amount in `label` weight, right aligned.
- Rows sit in a card separated by `line` hairlines — no per-row card.
- Swipe left reveals Delete on `danger`; release deletes and shows an Undo snackbar.
- Tap opens the edit sheet.
