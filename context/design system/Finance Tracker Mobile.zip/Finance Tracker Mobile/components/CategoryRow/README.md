# CategoryRow

A category's share of spending, shown in Activity when a scope is chosen.

- Same anatomy as TransactionRow, with a 4px bar under the name filled in the category's `cat-*` colour, scaled to the largest category.
- Count of transactions under the amount.
- Tap filters Activity to that category. Privacy on hides the bar as well as the amount.
