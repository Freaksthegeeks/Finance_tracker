# LoanBalance

Two balance tiles and the loan rows beneath them.

- Owed to you: `brand-soft` tile, `brand-ink` label, arrow-out icon. You owe: `owe-soft` tile, `owe` label, arrow-in icon.
- Rows: initial avatar on `surface-2`, person + note · date, amount in `brand` (lent) or `owe` (borrowed) with the direction word under it — colour is never the only cue.
- Settled rows: 60% opacity and strike-through; they live under the Settled segment.
