# AddExpenseSheet

The bottom sheet for adding and editing an expense (and, with a Lent/Borrowed segmented control on top, a loan entry).

- `surface`, `radius-xl` top corners, `shadow-sheet`, drag handle in `ink-faint`, over a `scrim`.
- Amount input centred, 40px bold, ₹ prefix in `ink-muted`, `brand` caret.
- Category grid: 4 columns; selected cell `brand-soft`.
- Primary button full width at the bottom, inside thumb reach. Edit mode adds a Delete text button in `danger` beside the title.
- Validation errors under the field in `danger`, `caption` size.
