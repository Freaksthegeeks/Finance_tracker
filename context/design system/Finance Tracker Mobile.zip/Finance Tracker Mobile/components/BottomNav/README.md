# BottomNav

Three destinations — Home, Activity, Loans — plus a floating Add button.

- Down from four tabs: Add is an action, not a place, so it became the FAB and a bottom sheet.
- Active item: `brand-soft` pill behind the icon, `brand-ink` icon, `ink` label. Inactive: `ink-muted`.
- FAB: `brand` fill, `on-brand` label, `shadow-fab`, a 56px circle with a plus, 16px from the right edge, 16px above the nav. Its accessible label changes per screen ("Add expense", "New loan entry"). Lists keep 88px of bottom padding so the last row clears it.
- Maps to Flutter `NavigationBar` with 3 destinations and a `FloatingActionButton.extended`.
