# Add expense

Adding an expense is a bottom sheet, not a tab, so it opens from wherever you are and closes back to it.

Order follows how people think: **amount → category → when → note → Save**.

- Amount is large and centred; the numeric keyboard opens immediately.
- Categories are an icon grid (8 visible, "More" reveals the other 3); last-used category is preselected.
- Date is a chip row: Today (default) · Yesterday · Pick date.
- Note is optional and single-line (maps to `description`; the backend accepts an empty string). Rows with no note show the category name as their title.
- Save stays disabled until the amount is valid (>0, ≤2 decimals). On success: close the sheet, show "Expense added" snackbar.
