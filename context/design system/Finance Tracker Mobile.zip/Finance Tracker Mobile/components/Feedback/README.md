# Feedback

Empty state, connection banner and snackbar.

- **Empty**: icon in a `brand-soft` circle, one-line title, one sentence, one primary action.
- **Banner** (offline / server waking): `owe-soft` with `owe` text and a Retry text button, under the header. Replaces the red error container.
- **Snackbar**: `ink` ground, `bg` text, Undo in `brand-soft`. Used for add, delete, settle — with Undo instead of confirm dialogs.
- Loading: show the last saved data with the stale sync dot; on a first launch, grey `surface-2` skeleton blocks in place of the hero and rows.
