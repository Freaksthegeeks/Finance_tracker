# SpendingChart

Daily bars for the selected month, built on the shadcn/ui **Bar Chart** pattern (Recharts `BarChart` inside `ChartContainer`).

- `CartesianGrid vertical={false}` in `chart-grid`; `XAxis` with `tickLine={false}` `axisLine={false}`; no y-axis. Five ticks: 1, 8, 15, 22, last day.
- `Bar radius={4}`: today in `chart-1` (sage), other days `chart-muted`; empty days draw nothing.
- Tooltip is `ChartTooltipContent`: `surface` card, `line` border, `shadow-tip`, bold date, a square `chart-1` indicator, muted label, bold tabular amount.
- Privacy on: keep the bars, hide the amount in the card header and tooltip.
- Flutter: `fl_chart` `BarChart` with the same settings (`FlGridData(drawVerticalLine:false)`, `BorderRadius.vertical(top: Radius.circular(4))`, a custom `BarTouchTooltipData`).
