# AppHeader

Screen title, month switcher and privacy toggle in one 48px row on `bg`.

- Title in `title`. Month pill: `surface` with a `line` border, ‹ › step one month, tapping the label opens the month/year sheet.
- Loans has no month pill (balances are across all dates).
- Eye icon toggles hidden amounts app-wide; icon flips to eye-off while hidden.
- Touch targets are 40px; the pill arrows 28px inside a 36px pill.
