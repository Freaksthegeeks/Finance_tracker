# Home

The home screen answers one question — how much have I spent this month — then gets out of the way.

Replaces the old Dashboard tab (4 stat tiles, loan summary, chart, recent, two category panels) with three blocks:

1. **Summary hero** (`brand-soft`): month total in `amount-hero`, then daily average, active categories and all-time in one row, then sync status.
2. **This month chart**: daily bars, today in `brand`, days with spend in `ink-faint`, empty days `surface-2`.
3. **Recent**: last 3–5 expenses, "See all" opens Activity filtered to the month.

Category breakdowns move into Activity (tap a category chip) and loan balances into Loans, so Home stays one thumb-scroll long.

- Month is changed in the header pill (‹ Nov 2026 ›); tap the label for a month/year sheet.
- The eye toggles privacy for every amount in the app.
- Refresh is pull-to-refresh only; the 15-second background refresh stays.
- The **+** FAB sits above the nav on Home and Activity.
