# CategoryDonut

Where the month's money went, as the shadcn/ui **Pie Chart – Donut with Text** (Recharts `PieChart` + `Pie innerRadius` + centre `Label`).

- Top 4 categories plus Others, each slice in its `cat-*` colour, 5px `surface` stroke between slices (`strokeWidth={5}`).
- Centre: total in bold `ink`, "this month" in `ink-muted`.
- Legend on the right: shadcn's square indicator, category in `ink-muted`, share in bold — colour is never the only key.
- Tap a slice or legend row to filter Activity to that category. Privacy on: centre shows ••••••, percentages stay.
- Flutter: `fl_chart` `PieChart(centerSpaceRadius: 56, sectionsSpace: 3)`.
