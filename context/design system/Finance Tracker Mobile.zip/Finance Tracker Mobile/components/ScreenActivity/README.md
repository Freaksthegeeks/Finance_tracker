# Activity

Every expense in one list — the old All Expenses tab, with filters folded into three light controls.

- **Search** (`surface-2` field) filters description and category as you type.
- **Scope** segmented control: Month · Year · All (the old DateScope).
- **Category chips** scroll horizontally; "All" first.
- **By category** donut (shadcn *Pie Chart – Donut with Text*) sits above the list for the chosen scope — this replaces the old Top Categories and yearly breakdown panels. Tapping a slice or legend row selects that category chip.
- Rows are **grouped by day**, each group header shows the day's total.
- Tap a row → edit sheet (same as the Add sheet, pre-filled, with a Delete text button).
- Swipe left → delete, with an Undo snackbar instead of a confirm dialog.
