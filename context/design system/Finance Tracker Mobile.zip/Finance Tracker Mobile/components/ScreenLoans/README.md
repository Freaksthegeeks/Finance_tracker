# Loans

Borrowed and lent money, kept apart from spending.

- **Balances**: two tiles — Owed to you (`brand`) and You owe (`owe` amber). Lightness and hue both differ, so they read without color vision.
- **Open · Settled** segmented control replaces the strike-through sort.
- Rows: initial avatar, person, note · date, amount coloured by direction with "Lent" / "Borrowed" under it.
- Swipe left → Mark settled (undo in snackbar); tap → edit sheet with Delete.
- The **+** FAB opens a sheet: Lent / Borrowed segmented, person, amount, date chip, note, Save.
